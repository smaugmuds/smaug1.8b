Liquidtable Replacement (v3.1)
==============================

http://www.afkmud.com/downloads.php?cat=noplex

Disclaimer
==========

This code isn't guarenteed to work correctly; it has been
tested on a highly modified version of Smaug 1.4a; and might not work
on your copy without some tweaking.


All support should be sent to: jbellone@comcast.net
Please include compiler errors/bugs/coredump (text; not file) if there is any.
And the OS that your mud is running on. (*nix flavor/varient; or windows x.x)

Overview
========

This code was designed to be a FULL replacement for the current (1.4a) version
of the Smaug liquidtable. It allows for liquids to be loaded from a seperate file
located in the system directory; which allows for the creation; edit and deletion of
liquids directly online; realtime; without any coding.

The earlier versions of the code only included the liquidtable replacement; soon followed
a mixture code that allowed liquids to be mixed together. Soon after this code was bugfixed
and introduced; it was adapted to use objects to mix with liquids.

This version (3.0) is a total rewrite of the old code; making it faster; more cleaner; and
hopefully more stable. It will also start to trickle in the new alchemey type system that will
be controlled similar to liquids and mixtures.

Credit
======

Credit goes out to everyone that gave me the original ideas for new adaptations to this code.
Sadiq also gave me the idea for the alchemey system; which hopefully will work out well.

Also would like to thank Samson for bugfixing the earlier versions of this code; without him
this code wouldn't be where it is today. (Atleast as quickly as it was ;)

Updating
========

If your updating from anything prior to version 2.9:

 Replace the liquids.c and liquids.h files.

 You will have to move the include for #include "liquids.h" in the mud.h directory under
 the bitvector structure.

 You will need to rename the liquids.dat and mixtures.dat files to
 liquidtable.dat and mixturetable.dat respectively.

 The code should automatically covert the old files to the new format (hasn't been extensively
 tested; so keep a backup) and there will also be a clean running version of both files with the
 distribution.

 All external calls to LIQ_DATA and/or MIX_DATA should be changed to LIQ_TABLE and/or MIX_TABLE
 respectively.

Instructions
============

(1) Back-up your areafiles.
(2) mud.h

Somewhere under:

After:

/*
 * Structure for extended bitvectors -- Thoric
 */
struct extended_bitvector
{
    unsigned int		bits[XBI]; /* Needs to be unsigned to compile in Redhat 6 - Samson */
};

Add:

/* Headers needing BITVECTORs */
#include "liquids.h" /* SMAUG Liquidtable Replacement  -Nopey */

After your last ITEM_*, add:
ITEM_DRINK_MIX

** Find the enum structure for CONDITIONS; remove that.

(3) db.c

After:

    log_string("Loading races");
    load_races();

Add:

    /* load liquids into the system from the liquidtable.dat file -Nopey */
    log_string("Loading liquids");
    load_liquids();

    /* load mixtures into the system from the mixturetable.dat file -Nopey */
    log_string("Loading mixtures");
    load_mixtures();

(4) misc.c

Remove the functions: do_fill, do_drink, do_empty

(These functions have been edited somewhat [do_drink moreso]
 so that they would be compadible with the new liquidtable system
 and are included in liquids.c)

(5) act_info.c

After:

	    if ( obj->value[1] <= 0 )
	    {
		send_to_char( "It is empty.\n\r", ch );
		if ( doexaprog ) oprog_examine_trigger( ch, obj );
		break;
	    }

Add this:

	/* exam addition for the new liquidtable	-Nopey */
	{
	  LIQ_TABLE *liq = get_liq_vnum(obj->value[2]);

	  ch_printf(ch, "It's %s full of a %s liquid.",
	    obj->value[1] <	obj->value[0] / 4 ? "less than" :
	    obj->value[1] < 3 * obj->value[0] / 4 ? "about"	: "more than",
	    liq->color );
	}

Make sure that you remove or comment out the code that resembles this,
it's different in some versions of Smaug/RM/SWR/AFKmud. You can either comment
it out or paste over it; either or will work fine.

(6) build.c

  Find:  char *  const	 o_types [] =

  Add "mix" at the end of of that array; be sure to add a , before the one before "mix"

(7) Add liquids.c, liquids.o, liquids.h to your makefile.
(8) Add liquidtable.dat, mixturetable.dat to your SYSTEM directory.

NOTE: liquidtable.dat includes preset liquids that are the Smaug originals,
      if you don't add these liquids, you will have area problems. I 
      suggest you add atleast liquidtable.dat, mixturetable.dat doesn't need
      to be added, but it includes a sample of a mixture.

(9) If your not using BFD code (found on Samson's site
    [http://www.alsherok.net/] you need to add the
    table entries for:

    do_setmixture
    do_setliquid
    do_mix

(10) Make clean, compile.
(11) Cedit do_setmixture, do_setliquid, do_mix, do_liquids.
(12) That's it!

Updates
=======

9/8/01	- Fixed the blood code. Blood wasn't working correctly, now it
	  can be set using the "setliquid" command. Also added a few
	  more ifchecks for liquids in places.
9/10/01 - Fixed a ifcheck in do_drink for vamps.
9/30/01 - A exam bug found by Sirek fixed in the additional instructions
	  included with the installation process.
11/3/01 - Ability to mix objects with the ITEM_DRINK_MIX type with liquids
	  in a container
	- Beginning support for a Alchemey system
6/2/02	- Rewrite of code
	- Beta testing of 3.0
	- Alchemey support flickering in
6/7/02	- Minor bugs crashing CB
	- OLC argument fixes
5/10/03 - Fixed some bugs (delayed update)

Note
====

Again, if you don't add the liquidtable.dat file into the system directory
you won't have any of the 15 or so Smaug liquids that all the areas used.

If you at ALL changed the liquid structure of your code, or added/removed
liquids, these directions will not work for you. If you changed liquids
or added them, you will need to edit the liquids.dat file, from either
online or offline.

Bugs
====

Bugs should be reported to the site where this code was downloaded.

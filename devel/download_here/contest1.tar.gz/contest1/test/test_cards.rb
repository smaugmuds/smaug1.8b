unless defined? $ZENTEST and $ZENTEST
require 'test/unit'
require 'cards'
end

class TestDeck < Test::Unit::TestCase
  def setup
    @d = Deck.new
  end
  def test_shuffle
    @d.shuffle
    assert_not_equal Deck.new.draw,@d.draw
  end
  def test_draw
    assert_equal "2S",@d.draw
    assert_equal "2C",@d.draw
    assert_equal 50,@d.count
  end
  def test_bury
    assert_equal false,@d.bury("2S")
    assert_equal "2S",@d.draw
    assert @d.bury("2S")
    assert_equal 52,@d.count
  end
  def test_count
    assert_equal "2S",@d.draw
    assert_equal 51,@d.count
  end
  def test_reset
    assert_equal "2S",@d.draw
    @d.reset
    assert_equal 52,@d.count
    assert_equal "2S",@d.draw
  end
  def test_values
    assert @d.values.slice(0..4)=="2S 2C"
  end
end
class TestHand < Test::Unit::TestCase
  def setup
    @d = Deck.new
    @h = Hand.new
  end
  def test_accept
    @h.accept @d.draw
    assert @h.has?("2S")
  end
  def test_count
    @h.accept @d.draw
    @h.accept @d.draw
    @h.accept @d.draw
    assert @h.count==3
  end
  def test_remove
    @h.accept @d.draw
    @h.accept @d.draw
    @h.accept @d.draw
    @h.accept @d.draw
    assert @h.has?("2S")
    @h.remove "2S"
    assert !@h.has?("2S")
  end
  def test_has_eh
    @h.accept @d.draw
    @h.accept @d.draw
    @h.accept @d.draw
    @h.accept @d.draw
    assert @h.has?("2H")
  end
  def test_values
    @h.accept @d.draw
    assert @h.values=="2S"
  end
end

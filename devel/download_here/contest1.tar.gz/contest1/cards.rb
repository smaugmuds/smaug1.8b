class Deck
  Suits=%w(S C D H)
  Ranks=%w(2 3 4 5 6 7 8 9 10 J Q K A)
  #  -method for the creation of a deck of 52 cards
  def initialize;reset;end
  #  -method to shuffle a deck of cards
  def shuffle;h=[];@d.each{|crd|h.insert(rand(h.size+1),crd)};@d=h;end
  #  -method to return the top card of a deck and removes it from the deck
  def draw;@d.shift;end
  #  -method to add a card to the bottom of the deck(the card should not already be in the deck)
  def bury c;!@d.include?(c)&&@d.push(c);end
  #  -method to return a value with total number of cards in deck
  def count;@d.size;end
  #  -method to reset the deck to 52 cards
  def reset;@d=[];Ranks.each{|i|Suits.each{|j|@d.push i+j}};end
  #  -method to return values of the cards in the deck ( H6, C3, SK, etc )
  def values;@d.inject{|s,c|s<<" "+c};end
end
class Hand
  #  -method to add a new empty hand to a player
  def initialize;@h=[];end
  #  -method to add a card to a players hand
  def accept c;@h.push c;end
  #  -method to count how many cards are in a hand
  def count;@h.size;end
  #  -method to remove a particular card from a hand.
  def remove c;@h.delete c;end
  #  -method that returns true if the hand contains one or more cards of a given value
  #  -method that returns true if the hand contains one or more cards of a given suit
  def has? v;@h.detect{|c|c=~/#{v}/};end
  #  -method to return values of the cards in a hand ( H6, C3, SK, etc )
  def values;@h.inject{|s,c|s<<" "+c};end
end


Modified Changes snippet.

Original copyrights belong to xkilla.
This snippet was last modified by Greven and Gavin of Dark Warriors. The original SWR port was by Atrox of Paradawn, and the original code was by Xkilla.

You may use this modifed code free, and pass it around and modify it as you like, as long as the comments are left in the files. Its not mandatory, but we would appreciate if you let the authors know that your using this code. You can reach them at darkwarsmud@hotmail.com. Any questions or problems with this snippet, please post your questions on http://www.dementiasystems.com/forum/. Please report any bugs or suggestions to darwarsmud@hotmail.com. Thanks.

This code has been tested on stock SWR, so it should work on any SWR, and likely and SMAUG as well.

Overview of commands:
-------------------------------------------------
changes      - Lists changes to player. If they are immortal, it will also show changes flagged as immchanges
chedit       - Allows player to delete changes, set a change as an immchange, and load/save the changes table
addchange    - Adds a change to the change table, and echoes to the mud
addimmchange - Adds an immchange to the change table

Instructions
-------------------------------------------------
db.c
----
At the top of the file, with the other include files, add the following after '#include "mud.h"'

#include "changes.h"

Search for:

        log_string( "Loading planets" );
        load_planets( );

And add below that:

        log_string( "Loading changes" );
        load_changes( );

tables.c
--------
In case 'a', add:

	if ( !str_cmp( name, "do_addchange" ))			return do_addchange;
	if ( !str_cmp( name, "do_addimmchange" ))		return do_addimmchange;

In case 'c', add:

	if ( !str_cmp( name, "do_chedit" ))			return do_chedit;
	if ( !str_cmp( name, "do_changes" ))			return do_changes;

Farther down, search for:

    if ( skill == do_advance )		return "do_advance";

Add below that add:

    if ( skill == do_addimmchange )		return "do_addimmchange";
    if ( skill == do_addchange )		return "do_addchange";

Find:

    if ( skill == do_check_vnums )	return "do_check_vnums";

And bellow add:

    if ( skill == do_chedit )		return "do_cheidt";
    if ( skill == do_changes )		return "do_changes";

makefile
--------

In you makefile, add changes.c to C_FILES, and changes.o to your O_FILES

Copy the changes.dat file into your system directory.

Make clean, compile, and reboot/copyover/hotboot your mud.

From within the mud, add:

cedit changes create do_changes
cedit changes level 105
cedit changes addchange do_addchange
cedit changes level 105
cedit changes addimmchange do_addimmchange
cedit changes level 105
cedit changes chedit do_chedit
cedit changes level 105


Ok, that should be it. Now you add commands with addchange, and view them with changes. If you have more than 10, and you want to see all of the changes, use "changes all"
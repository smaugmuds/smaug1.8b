This will give you a generic enlist for all for your clans.



** in clans.c **

Change do_enlist to this :


void do_enlist( CHAR_DATA *ch, char *argument )
{

	CLAN_DATA *clan;
        
	if ( IS_NPC(ch) || !ch->pcdata )
	{
	    send_to_char( "You can't do that.\n\r", ch );
	    return;
	}
        
	if ( ch->pcdata->clan )
	{
		ch_printf( ch , "You will have to resign from %s before you can join a new organization.\n\r", ch->pcdata->clan->name );
		return;
	}
        
	if ( ! IS_SET( ch->in_room->room_flags , ROOM_RECRUIT ) )
	{
		send_to_char( "You don't seem to be in a recruitment office.\n\r", ch );
		return;
	}
	
	for ( clan = first_clan; clan; clan = clan->next )
	{
		if ( ch->in_room->vnum == clan->enlistroom )
		{
			SET_BIT( ch->speaks, LANG_CLAN );
			++clan->members;
			STRFREE( ch->pcdata->clan_name );
			ch->pcdata->clan_name = QUICKLINK( clan->name );
			ch->pcdata->clan = clan;
			ch_printf( ch, "Welcome to %s.\n\r", clan->name );
			save_clan ( clan );
			return;
		}
	}

	send_to_char( "They don't seem to be recruiting right now.\n\r", ch );
	return;

}


add to fread_clan :

in CASE 'E'

	KEY( "Enlist",	clan->enlistroom,		fread_number( fp ) );



in to do_setclan :

change :

send_to_char( " leader number1 number2 subclan\n\r", ch ); 

to :

send_to_char( " leader number1 number2 subclan enlistroom\n\r", ch );

Add : 

	if ( !strcmp( arg2, "enlistroom" ) )
	{
		clan->enlistroom = atoi( argument );
		send_to_char( "Done.\n\r", ch );
		save_clan( clan );
		return;
	}

in do_showclan :

Add :

    ch_printf( ch, "Enlist Room: %ld\n\r",
    			clan->enlistroom );

in save_clan

Add :

	fprintf( fp, "Enlist         %d\n", clan->enlistroom );



** in mud.h **

In struct	clan_data  add :

	int         enlistroom;

change :

	#define ROOM_R_RECRUIT          BV27

to :

	#define ROOM_RECRUIT          BV27

ROOM_E_RECRUIT is now a free flag, us it for whatever you like.


** build.c **

change "republic_recruit" to "recruit"
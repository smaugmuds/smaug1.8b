/***************************************************************************
 * This code may be used freely within any non-commercial MUD, all I ask   *
 * is that these comments remain in tact and that you give me any feedback *
 * or bug reports you come up with.  The helpfile distributed with this    *
 * code must also remain in tact.                                          *
 *                                  -- Midboss (eclipsing.souls@gmail.com) *
 ***************************************************************************/

/*
 * If your MUD has more weapon types, add them to the custom_weapon_table,
 * and increment this define to match.
 */
#define MAX_WEAPON_TYPE 9


/*
 * Custom weapon vnums.  You may have to create these objects yourself, and
 * adjust the vnums accordingly.  If you forget to do this, it'll do bad
 * things to your MUD.
 */
#define OBJ_VNUM_CUSTOM_SWORD		31
#define OBJ_VNUM_CUSTOM_DAGGER		32
#define OBJ_VNUM_CUSTOM_SPEAR		33
#define OBJ_VNUM_CUSTOM_MACE		34
#define OBJ_VNUM_CUSTOM_AXE			35
#define OBJ_VNUM_CUSTOM_FLAIL		36
#define OBJ_VNUM_CUSTOM_WHIP		37
#define OBJ_VNUM_CUSTOM_POLEARM		38

/* 7500 per level, 75000 total */

#define set_damage(obj)                                                    \
		(obj)->value[1] = base_damage[(obj)->cust_level+(obj)->damage][0]  \
						      + custom_table[(obj->value[0])].modifier[0]; \
		(obj)->value[2] = base_damage[(obj)->cust_level+(obj)->damage][1]  \
						      + custom_table[(obj->value[0])].modifier[1]; \

struct custom_type
{
	sh_int	modifier[2]; //Dice modifiers.
	char * 	names[25];   //The list of acceptable names.
	char * 	verbs[10];   //The list of acceptable names.
};

extern const struct custom_type custom_table	[MAX_WEAPON_TYPE];
extern		 sh_int				base_damage		[21][2];


OBJ_DATA *	get_custom			(CHAR_DATA * ch);
void		gain_oexp			(CHAR_DATA * ch, int gain);

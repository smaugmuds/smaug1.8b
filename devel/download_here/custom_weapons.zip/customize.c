/***************************************************************************
 * This code may be used freely within any non-commercial MUD, all I ask   *
 * is that these comments remain in tact and that you give me any feedback *
 * or bug reports you come up with.  The helpfile distributed with this    *
 * code must also remain in tact.                                          *
 *                                  -- Midboss (eclipsing.souls@gmail.com) *
 ***************************************************************************/
#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "merc.h"
#include "recycle.h"
#include "customize.h"

/*
 * This is the core of the customizable weapons system.
 */
void do_customize (CHAR_DATA * ch, char * argument)
{
	char arg[MIL];
	OBJ_DATA * obj;
	AFFECT_DATA af;
	argument = one_argument (argument, arg);

	/*
	 * Aw, no weapon?
	 */
	if ((obj = get_custom (ch)) == NULL)
	{
		send_to_char ("You have no customizable weapon.  Try outfit.\n\r", ch);
		return;
	}

	/*
	 * No argument?
	 */
	if (arg[0] == '\0')
	{
		send_to_char ("Customize which aspect of your weapon?\n\r"
		              "   damage    restring    affects      \n\r"
		              "   stats                              \n\r"
		              "                          check       \n\r", ch);
		return;
	}

	/*
	 * Are they still using it?  Let them 'check' anyway.
	 */
	if (obj->wear_loc != WEAR_NONE && str_prefix (arg, "check"))
	{
		send_to_char ("You should remove it first.\n\r", ch);
		return;
	}

	/*
	 * Check status.
	 */
	else if (!str_prefix (arg, "check"))
	{
		//Much of this is copy/paste from do_ostat.
		char buf[MSL];
		AFFECT_DATA *paf;

		//Give them the weapon type.
		send_to_char ("Your weapon's type is ", ch);
        switch (obj->value[0])
        {
			default:
				send_to_char ("Error", ch);
                break;
			case (WEAPON_SWORD):
				send_to_char ("Sword", ch);
				break;
			case (WEAPON_DAGGER):
				send_to_char ("Dagger", ch);
				break;
			case (WEAPON_SPEAR):
				send_to_char ("Spear", ch);
				break;
			case (WEAPON_MACE):
				send_to_char ("Mace", ch);
				break;
			case (WEAPON_AXE):
				send_to_char ("Axe", ch);
				break;
			case (WEAPON_FLAIL):
				send_to_char ("Flail", ch);
				break;
			case (WEAPON_WHIP):
				send_to_char ("Whip", ch);
				break;
			case (WEAPON_POLEARM):
				send_to_char ("Polearm", ch);
				break;
		}
		//Now print the dice...
		printf_to_char (ch, ", with damage of %dd%d (average %d).\n\r",
							obj->value[1], obj->value[2],
							(1 + obj->value[2]) * obj->value[1] / 2);

		//Experience stuff.
		printf_to_char (ch, "Your weapon is level %d, with %d experience to level.\n\r"
							"It has %ld experience left to spend.",
							obj->cust_level, obj->to_level, 7500 - obj->experience);

		//Loop through affects...
		for (paf = obj->affected; paf != NULL; paf = paf->next)
		{
			//Only show the numbers if they exist.
			if (paf->modifier != 0)
			{
				sprintf (buf, "Affects %s by %d",
						 affect_loc_name (paf->location), paf->modifier);
					send_to_char (buf, ch);

				if (paf->duration > -1)
					sprintf (buf, " for %d hours.\n\r", paf->duration);
				else
					sprintf (buf, ".\n\r");

				send_to_char (buf, ch);
			}

			//Now if they have a bitvector, show it.
			if (paf->bitvector)
			{
				switch (paf->where)
				{
					case TO_AFFECTS:
						sprintf (buf, "Adds %s affect.\n",
								 affect_bit_name (paf->bitvector));
						break;
					case TO_WEAPON:
						sprintf (buf, "Adds %s weapon flags.\n",
								 weapon_bit_name (paf->bitvector));
						break;
					case TO_OBJECT:
						sprintf (buf, "Adds %s object flag.\n",
								 extra_bit_name (paf->bitvector));
						break;
					case TO_IMMUNE:
						sprintf (buf, "Adds immunity to %s.\n",
								 imm_bit_name (paf->bitvector));
						break;
					case TO_RESIST:
						sprintf (buf, "Adds resistance to %s.\n\r",
								 imm_bit_name (paf->bitvector));
						break;
					case TO_VULN:
						sprintf (buf, "Adds vulnerability to %s.\n\r",
								 imm_bit_name (paf->bitvector));
						break;
					default:
						sprintf (buf, "Unknown bit %d: %d\n\r",
								 paf->where, paf->bitvector);
						break;
				}
				send_to_char (buf, ch);
			}
		}
	}

	/*
	 * Damage improvement!
	 */
	else if (!str_prefix (arg, "damage"))
	{
		//Already maxed?
		if (obj->damage >= 10)
		{
			send_to_char ("Your weapon is as powerful as it can be.\n\r", ch);
			return;
		}
		//Not enough XP?
		if (obj->experience < 5000)
		{
			send_to_char ("Your weapon doesn't have enough experience!\n\r", ch);
			return;
		}

		//Boost the damage rank.
		obj->damage += 1;
		obj->experience -= 5000;
	
		//Reset the dice.
		set_damage (obj);
		send_to_char ("Your weapon's attack power increases!\n\r", ch);
		return;
	}
	/*
	 * Haste, Sanc, Invis, Infravision, Detect Hidden, Detect Invis, Sneak,
	 * Fly, or Regen.
	 */
	else if (!str_prefix (arg, "affects"))
	{
		int i = 0, affect = -1;

		int costs[12] = {1000, 1750, 1750, 2050, 2750, 3500,
						 6500, 6750, 6750, 7500, 7500, 15000};

		long bits[12] = {AFF_INFRARED, AFF_DETECT_HIDDEN, AFF_DETECT_INVIS, 
			             AFF_FLYING, AFF_PASS_DOOR, AFF_SNEAK, AFF_INVISIBLE,
						 AFF_PROTECT_EVIL, AFF_PROTECT_GOOD, AFF_HASTE,
						 AFF_REGENERATION, AFF_SANCTUARY};

		char * names[12] ={"infravision", "detect hidden", "detect invis", "fly",
						   "pass door", "sneak", "invisibility", "protection evil",
						   "protection good", "haste", "regeneration", "sanctuary"};

		//No arg, display a list.
		if (argument[0] == '\0')
		{
			send_to_char ("Add which affect?\n\r"
				"   Infravision.......1000exp    Detect Hidden.....1750exp\n\r"
				"   Detect Invis......1750exp    Fly...............2050exp\n\r"
				"   Pass Door.........2750exp    Sneak.............3500exp\n\r"
				"   Invisibility......6500exp    Protection Evil...6750exp\n\r"
				"   Protection Good...6750exp    Haste.............7500exp\n\r"
				"   Regeneration......7500exp    Sanctuary........15000exp\n\r", ch);
			return;
		}

		//Look up the affect in the name array.
		for (i = 0; names[i] != NULL; i++)
		{
			if (!str_prefix (argument, names[i]))
			{
				affect = i;
				break;
			}
		}

		//Bad affect, display a list.
		if (affect < 0)
		{
			send_to_char ("Add which affect?\n\r"
				"   Infravision.......1000exp    Detect Hidden.....1750exp\n\r"
				"   Detect Invis......1750exp    Fly...............2050exp\n\r"
				"   Pass Door.........2750exp    Sneak.............3500exp\n\r"
				"   Invisibility......6500exp    Protection Evil...6750exp\n\r"
				"   Protection Good...6750exp    Haste.............7500exp\n\r"
				"   Regeneration......7500exp    Sanctuary........15000exp\n\r", ch);
			return;
		}

		//Make sure they have enough XP.
		if (obj->experience < costs[affect])
		{
			send_to_char ("Your weapon doesn't have enough experience!\n\r", ch);
			return;
		}

		//Distribute the affect.
		af.where = TO_AFFECTS;
		af.type = 0;
		af.duration = -1;
		af.bitvector = bits[affect];
		af.level = obj->level;
		af.location = APPLY_NONE;
		af.modifier = 0;
        affect_to_obj (obj, &af);

		//Eat up the experience.
		obj->experience -= costs[affect];
		send_to_char ("Affect added.\n\r", ch);
		return;
	}
	/*
	 * Weapon flags.
	 */
	else if (!str_prefix (arg, "flags"))
	{
		int i = 0, flag = -1;

		int costs[8] = {14750, 14750, 14750, 13500,
						13500, 9500, 12500, 5000};

		long bits[8] = {WEAPON_FLAMING, WEAPON_FROST, WEAPON_SHOCKING, 
						 WEAPON_VAMPIRIC, WEAPON_POISON, WEAPON_SHARP,
						 WEAPON_VORPAL, WEAPON_TWO_HANDS};

		char * names[8] ={"flaming", "frost", "shocking", "vampiric", "poison",
						   "sharp", "vorpal", "twohanded"};

		//Display a list...
		if (argument[0] == '\0')
		{
			send_to_char ("Add which flag?\n\r"
				"   Flaming..........14750exp    Frost............14750exp\n\r"
				"   Shocking.........14750exp    Vampiric.........13500exp\n\r"
				"   Poison...........13500exp    Sharp.............9500exp\n\r"
				"   Vorpal...........12500exp    Twohanded.........5000exp\n\r", ch);
			return;
		}

		//Look it up...
		for (i = 0; names[i] != NULL; i++)
		{
			if (!str_prefix (argument, names[i]))
			{
				flag = i;
				break;
			}
		}

		//Display a list if it wasn't found...
		if (flag < 0)
		{
			send_to_char ("Add which flag?\n\r"
				"   Flaming..........14750exp    Frost............14750exp\n\r"
				"   Shocking.........14750exp    Vampiric.........13500exp\n\r"
				"   Poison...........13500exp    Sharp.............9500exp\n\r"
				"   Vorpal...........12500exp    Twohanded.........5000exp\n\r", ch);
			return;
		}

		//XP check...
		if (obj->experience < costs[flag])
		{
			send_to_char ("Your weapon doesn't have enough experience!\n\r", ch);
			return;
		}

		//Set the flag and eat up some XP...
		SET_BIT (obj->value[4], bits[flag]);
		obj->experience -= costs[flag];
		send_to_char ("Weapon flag added.\n\r", ch);
		return;
	}
	/*
	 * Stat boosts.
	 */
	else if (!str_prefix (arg, "stats"))
	{
		int i = 0, stat = -1;

		int costs[12] = {2500, 2500, 2500, 2500, 2500, 1875,
						 1875, 1875, 3000, 1500, 1500, 1500};

		long loc[12] = {APPLY_STR, APPLY_DEX, APPLY_CON, APPLY_WIS, APPLY_INT,
						APPLY_HIT, APPLY_MANA, APPLY_MOVE, APPLY_SAVES,
						APPLY_AC, APPLY_HITROLL, APPLY_DAMROLL};

		sh_int mod[12] = {1, 1, 1, 1, 1, 5, 5, 5, -1, -2, 1, 1};

		char * names[12] ={"strength", "dexterity", "constitution", "wisdom",
						   "intelligence", "hit points", "mana", "movement",
						   "saving throw", "armor class", "hitroll", "damroll"};

		//List...  See a pattern forming?
		if (argument[0] == '\0')
		{
			send_to_char ("Add to which stat?\n\r"
				"   Strength..........2500exp    Dexterity...,.....2500exp\n\r"
				"   Constitution......2500exp    Wisdom............2500exp\n\r"
				"   Intelligence......2500exp    Hit Points........1875exp\n\r"
				"   Mana..............1875exp    Movement..........1875exp\n\r"
				"   Saving Throw......3000exp    Armor Class.......1500exp\n\r"
				"   Hitroll...........1500exp    Damroll...........1500exp\n\r", ch);
			return;
		}

		//Lookup...  You know, a pattern?
		for (i = 0; names[i] != NULL; i++)
		{
			if (!str_prefix (argument, names[i]))
			{
				stat = i;
				break;
			}
		}

		//List...  When things are done repetitively?
		if (stat < 0)
		{
			send_to_char ("Add to which stat?\n\r"
				"   Strength..........2500exp    Dexterity...,.....2500exp\n\r"
				"   Constitution......2500exp    Wisdom............2500exp\n\r"
				"   Intelligence......2500exp    Hit Points........1875exp\n\r"
				"   Mana..............1875exp    Movement..........1875exp\n\r"
				"   Saving Throw......3000exp    Armor Class.......1500exp\n\r"
				"   Hitroll...........1500exp    Damroll...........1500exp\n\r", ch);
			return;
		}

		//Check experience...  Ah well.
		if (obj->experience < costs[stat])
		{
			send_to_char ("Your weapon doesn't have enough experience!\n\r", ch);
			return;
		}

		//Add the affect...  Maybe I'm just rambling.
		af.where = TO_AFFECTS;
		af.type = 0;
		af.duration = -1;
		af.bitvector = 0;
		af.level = obj->level;
		af.location = loc[stat];
		af.modifier = mod[stat];
        affect_to_obj (obj, &af);

		//Eat up experience and stuff.
		obj->experience -= costs[stat];
		send_to_char ("Attribute boosted.\n\r", ch);
		return;
	}
	/*
	 * Restringing for max level items.
	 */
	else if (!str_prefix (arg, "restring"))
	{
		bool found = FALSE;
		char arg2[MIL];
		int i;

		//Not maxed?
		if (obj->cust_level < 10)
		{
			send_to_char ("You can't restring your weapon yet!\n\r", ch);
			return;
		}

		argument = one_argument (argument, arg2);

		//No string specified.
		if (arg2[0] == '\0')
		{
			send_to_char ("Change which string [short|long|name|damverb]?\n\r", ch);
			return;
		}

		//No replacement specified.
		if (argument[0] == '\0')
		{
			send_to_char ("Change it to what?\n\r"
						  "Remember to include one of the following:\n\r", ch);
			for (i = 0; custom_table[obj->value[0]].names[i] != NULL; i++)
				printf_to_char (ch, "%s%s", custom_table[obj->value[0]].names[i],
								i % 4 == 0 ? "\n\r" : "    ");
			return;
		}

		//Check for the acceptable names.
		for (i = 0; custom_table[obj->value[0]].names[i] != NULL; i++)
		{
			if (strstr (argument, custom_table[obj->value[0]].names[i]))
			{
				found = TRUE;
				break;
			}
		}

		if (!found)
		{
			send_to_char ("All restring fields must contain an acceptable"
						  "name.\n\r", ch);
			return;
		}

		smash_tilde (argument);

		//Now change the string.
		if (str_prefix (arg2, "short"))
		{
			free_string (obj->short_descr);
			obj->short_descr = str_dup (argument);
		}
		else if (str_prefix (arg2, "long"))
		{
			free_string (obj->description);
			obj->description = str_dup (argument);
		}
		else if (str_prefix (arg2, "name"))
		{
			free_string (obj->name);
			obj->name = str_dup (argument);
		}
		//Special case for damverbs.
		else if (str_prefix (arg2, "damverb"))
		{
			int dv = -1;

			//Look one up in the custom table.
			for (i = 0; custom_table[obj->value[0]].verbs[i] != NULL; i++)
			{
				if (!str_prefix (argument, custom_table[obj->value[0]].verbs[i]))
				{
					dv = i;
					break;
				}
			}

			if (dv < 0)
			{
				send_to_char ("Bad damverb.\n\r", ch);
				return;
			}

			//Now set the damverb to an ACTUAL attack_table entry.
			dv = attack_lookup (custom_table[obj->value[0]].verbs[dv]);

			//Is our table screwed up?
			if (dv < 0)
			{
				send_to_char ("Broken damverb.\n\r", ch);
				return;
			}

			//Change the value.
			obj->value[3] = dv;
			send_to_char ("Damverb changed.\n\r", ch);
			return;
		}
		//Bad string name, ask again.
		else
		{
			send_to_char ("Change which string [short|long|name|damverb]?\n\r", ch);
			return;
		}
		//All is well!
		send_to_char ("String changed.\n\r", ch);
		return;
	}
	//Bail out if it didn't match anything.
	else
	{
		send_to_char ("Invalid customization field.\n\r", ch);
		return;
	}
}

/*
 * Grabs a character's customizable weapon.
 */
OBJ_DATA * get_custom (CHAR_DATA * ch)
{
	OBJ_DATA * xObj, * yObj;

	for (xObj = ch->carrying; xObj != NULL; xObj = xObj->next_content)
	{
		//We have to loop through containers, too.
		if (xObj->item_type == ITEM_CONTAINER)
		{
			for (yObj = xObj->contains; yObj != NULL;
				 yObj = yObj->next_content)
				if (IS_SET (yObj->extra_flags, ITEM_CUSTOMIZE))
							return yObj;
		}
		else if (IS_SET (xObj->extra_flags, ITEM_CUSTOMIZE))
			return xObj;
	}
	return NULL;
}

/*
 * Gains experience for an object.
 */
void gain_oexp (CHAR_DATA * ch, int gain)
{
	OBJ_DATA * obj;

	if ((obj = get_custom (ch)) != NULL)
	{
		if (obj->cust_level < 10)
		{
			obj->experience = URANGE (obj->experience,
								obj->experience + gain, 75000);
			
			obj->to_level += gain;

			while (obj->to_level >= 7500)
			{
				obj->cust_level += 1;
				obj->to_level -= 7500;
				set_damage (obj);
			}
		}
	}
	return;
}


/***************************************************************************
 * base_damage table provided for convenience.                             *
 * ----------------------------------------------------------------------- *
 *       Rank 1:   2d6  (average  6)     Rank 2:   3d4  (average  6)       *
 *       Rank 3:   3d7  (average 10)     Rank 4:   4d6  (average 12)       *
 *       Rank 5:   3d10 (average 15)     Rank 6:   5d6  (average 15)       *
 *       Rank 7:   4d9  (average 18)     Rank 8:   5d9  (average 22)       *
 *       Rank 9:   6d8  (average 24)     Rank 10:  6d9  (average 27)       *
 *       Rank 11:  9d6  (average 27)     Rank 12:  7d9  (average 31)       *
 *       Rank 13:  9d7  (average 31)     Rank 14:  8d9  (average 36)       *
 *       Rank 15:  9d8  (average 36)     Rank 16:  7d11 (average 38)       *
 *       Rank 17: 11d7  (average 38)     Rank 18:  8d10 (average 40)       *
 *       Rank 19:  8d11 (average 44)     Rank 20: 11d9  (average 49)       *
 ***************************************************************************/

sh_int	base_damage[21][2] ={
{ 0, 0}, { 2, 6}, { 3, 4}, { 3, 7}, { 4, 6}, { 3,10},
		 { 5, 6}, { 4, 9}, { 5, 9}, { 6, 8}, { 6, 9},
	     { 9, 6}, { 7, 9}, { 9, 7}, { 8, 9}, { 9, 8},
	     { 7,11}, {11, 7}, { 8,10}, { 8,11}, {11, 9}
};

/*
 * The weapon customization table. Make absolutely certain that this stays
 * in the same order as your WEAPON_* defines.
 */
const struct custom_type custom_table [MAX_WEAPON_TYPE] = {
    {
	 {0, 0},
	 {NULL},
	 {NULL},
	},

    {
	 {0, 0},
     {"sword", "blade", "edge", "rapier", "cinqueda", "schiavona", 
      "shortsword", "broadsword", "longsword", "greatsword", "epee",
      "falchion", "foil", "sabre", "saber", "cutlass", "scimitar",
      "shamshir"},
	 {"slash", "thrust", "slice", "pierce", "stab"}
    },

    {
	 {-1, -1},
     {"dagger", "main gauche", "knife", "edge", "blade"},
	 {"slash", "thrust", "slice", "pierce", "stab"}
    },

    {
	 {1, 0},
     {"spear", "javelin", "trident", "lance", "staff", "ranseur"},
	 {"slash", "thrust", "slice", "pierce", "thwack", "beating"}
    },

	{
	 {-1, 1},
     {"mace", "club", "rod", "cane", "hammer", "warhammer"},
	 {"pound", "thwack", "beating", "crush", "smash"}
    },

    {
	 {1, 1},
     {"axe", "hatchet", "battleaxe", "pick", "scythe"},
	 {"cleave", "slash", "chop"}
    },

    {
	 {-1, 0},
     {"flail", "nunchaku", "nunchakus", "morning star"},
	 {"thwack", "beating", "crush", "smash"},
	},

    {
	 {0, -1},
     {"whip", "coil", "nine tails", "nine-tails", "nine tailed"},
	 {"whip"}
    },

    {
	 {0, 1},
     {"polearm", "poleaxe", "glaive", "halberd", "bardiche"},
	 {"slash", "cleave", "thrust", "slice", "chop"}
    }
};


/******************************************************************************\
*   Card code is Copyright 2005 Cameron Taylor                                 *
*   Developed by Cameron Taylor (Shanyr) for the Mud Magic Code Challenge      *
*   See included 'card_license.txt' for license conditions.                    *
\******************************************************************************/


#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "merc.h"
#include "card.h"


/*
 * Prototypes ******************************************************************
 */

/* Intended for local use only, so not in card.h */
int card_setlasterror(int err);

CARD_DATA * new_card();
void free_card(CARD_DATA * card);
CARD_DECK * new_deck();
void free_deck(CARD_DECK * deck);
CARD_HAND * new_hand();
void free_hand(CARD_HAND * hand);


/*
 * Variables *******************************************************************
 */
extern char str_empty[1];

int card_lasterror = CARD_ERR_NONE;

/*#define CARD_USE_COLOR*/
#ifdef CARD_USE_COLOR
char * suits[] = {"{KS{x", "{KC{x", "{RD{x", "{RH{x"};
char * ranks[] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
#define CARD_LEN 8
#else
char * suits[] = {"S", "C", "D", "H"};
char * ranks[] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
#define CARD_LEN 4
#endif

/*
 * Deck functions **************************************************************
 */

/*
 * Creates a new deck of 52 cards.
 */
CARD_DECK * card_deck_create(void)
{
    CARD_DECK * deck = NULL;
    CARD_DATA * card = NULL;
    int s, r;

    deck = new_deck();
    deck->hand_list = NULL;
    deck->returns = card_hand_create(deck);
    deck->top = deck->bottom = NULL;
    deck->count = 0;


    /* Create and add 52 cards */
    for(s=CARD_SUIT_MIN; s<=CARD_SUIT_MAX; s++)
        for(r=CARD_RANK_MIN; r<=CARD_RANK_MAX; r++)
        {
            card = new_card();
            card->deck = deck;
            card->suit = s;
            card->rank = r;
            card_deck_addbottom(deck, card);
        }

    return deck;
}

/*
 * Retrieves all cards from all hands associated with this deck.
 */
int card_deck_reset(CARD_DECK * deck)
{
    CARD_HAND * hand;

    if(deck == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    /* retrieve the cards from the hands */
    for(hand=deck->hand_list; hand!=NULL; hand=hand->next)
        card_hand_returntodeck(hand);

    /* put cards back in deck */
    hand = deck->returns;
    if(hand->top != NULL)
    {
        hand->bottom->next = deck->top;
        deck->top->prev = hand->bottom;
        hand->top->prev = deck->bottom;
        deck->bottom->next = hand->top;
        deck->bottom = hand->bottom;
    }
    deck->count += hand->count;
    hand->top = hand->bottom = NULL;
    hand->count = 0;

    return card_setlasterror(CARD_ERR_NONE);
}

/*
 * Destroys this deck.  Empties all hands associated with this deck.
 */
int card_deck_destroy(CARD_DECK * deck)
{
    CARD_DATA * card;

    if(deck == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    card_deck_reset(deck);

    /* Free all cards */
    while((card = card_deck_drawtop(deck)) != NULL)
        free_card(card);

    card_hand_destroy(deck->returns);
    free_deck(deck);
    return card_setlasterror(CARD_ERR_NONE);
}

/*
 * Shuffles the deck.  Cards from players who have quit the game
 * are returned to the deck.
 * Returns 0 on success, error code on failure.
 */
int card_deck_shuffle(CARD_DECK * deck)
{
    CARD_HAND * hand;
    CARD_DATA * start, * end;
    int i, j, k, t;

    if(deck == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    /* put cards back in deck */
    hand = deck->returns;
    if(hand->top != NULL)
    {
        hand->bottom->next = deck->top;
        deck->top->prev = hand->bottom;
        hand->top->prev = deck->bottom;
        deck->bottom->next = hand->top;
        deck->bottom = hand->bottom;
    }
    deck->count += hand->count;
    hand->top = hand->bottom = NULL;
    hand->count = 0;

    if(deck->count == 0)
        return card_setlasterror(CARD_ERR_NOCARD);

    start = end = deck->top;
    for(i=0; i<deck->count*5; i++)
    {
        k = rand() % 100 + 1;
        start = end;
        for(j=0; j<k; j++)
            end = end->next;
        /* swap end with start */
        t = start->rank;
        start->rank = end->rank;
        end->rank = t;
        t = start->suit;
        start->suit = end->suit;
        end->suit = t;
    }

    return card_setlasterror(CARD_ERR_NONE);
}

/*
 * Removes the top card from the deck.
 * Returns the card removed, or NULL if the deck is empty.
 */
CARD_DATA * card_deck_drawtop(CARD_DECK * deck)
{
    CARD_DATA * card;

    if(deck == NULL)
    {
        card_setlasterror(CARD_ERR_NULL);
        return NULL;
    }

    if(deck->count == 0)
    {
        card_setlasterror(CARD_ERR_NOCARD);
        return NULL;
    }

    if(--(deck->count) == 0)
    {
        card = deck->top;
        deck->top = NULL;
        deck->bottom = NULL;
    }
    else
    {
        card = deck->top;
        deck->top = deck->top->next;
        deck->top->prev = deck->bottom;
        deck->bottom->next = deck->top;
    }

    card->prev = NULL;
    card->next = NULL;
    card_setlasterror(CARD_ERR_NONE);
    return card;
}

/*
 * Adds a card at the bottom of the deck.
 * Returns 0 on success, error code on failure.
 */
int card_deck_addbottom(CARD_DECK * deck, CARD_DATA * card)
{
    if(card == NULL || deck == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    if(card->deck != deck)
        return card_setlasterror(CARD_ERR_DECK);

    if(deck->count == 0)
    {
        card->prev = card;
        card->next = card;
        deck->top = card;
        deck->bottom = card;
    }
    else
    {
        card->next = deck->top;
        card->prev = deck->bottom;
        deck->bottom = card;
        card->next->prev = card;
        card->prev->next = card;
    }

    deck->count++;
    return card_setlasterror(CARD_ERR_NONE);
}

/*
 * Returns the number of cards in the deck, or a (negative) error code.
 */
int card_deck_count(CARD_DECK * deck)
{
    if(deck == NULL)
        return -card_setlasterror(CARD_ERR_NULL);

    card_setlasterror(CARD_ERR_NONE);

    return deck->count;
}

/*
 * Returns a string representation of all the cards in the deck.
 * The returned string is allocated using str_dup() and should be
 *   released using free_string().
 */
char * card_deck_getallcards(CARD_DECK * deck)
{
    CARD_DATA * card;
    char buf[CARD_LEN * 52 + 1];  /* data buffer */
    char fbuf[CARD_LEN * 52 + 1]; /* format buffer */

    if(deck == NULL)
    {
        card_setlasterror(CARD_ERR_NULL);
        return &str_empty[0];
    }

    if(deck->count == 0)
        return &str_empty[0];

    buf[0] = fbuf[0] = '\0';

    for(card=deck->top; ; card=card->next)
    {
        strcat(fbuf, "%s%s ");
        sprintf(buf, fbuf, suits[card->suit], ranks[card->rank]);
        strcpy(fbuf, buf);

        if(card == deck->bottom)
            break;
    }

    return str_dup(buf);
}



/*
 * Hand functions **************************************************************
 */

/*
 * Creates a new hand associated with the specified deck.
 */
CARD_HAND * card_hand_create(CARD_DECK * deck)
{
    CARD_HAND * hand;

    if(deck == NULL)
    {
        card_setlasterror(CARD_ERR_NULL);
        return NULL;
    }

    hand = new_hand();
    hand->deck = deck;
    hand->next = deck->hand_list;
    deck->hand_list = hand;
    hand->top = NULL;
    hand->bottom = NULL;
    hand->count = 0;
    return hand;
}

/*
 * Deletes the specified hand.
 */
void card_hand_destroy(CARD_HAND * hand)
{
    if(hand == NULL)
    {
        card_setlasterror(CARD_ERR_NULL);
        return;
    }

    /* Return this hand's cards to the deck */
    card_hand_returntodeck(hand);

    free_hand(hand);
}

/*
 * Adds a card to the hand.
 * Returns 0 on success, error code on failure.
 */
int card_hand_add(CARD_HAND * hand, CARD_DATA * card, int faceup)
{
    if(card == NULL || hand == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    if(card->deck != hand->deck)
        return card_setlasterror(CARD_ERR_DECK);

    card->faceup = faceup;
    if(hand->count == 0)
    {
        card->prev = card;
        card->next = card;
        hand->top = card;
        hand->bottom = card;
    }
    else
    {
        card->next = hand->top;
        card->prev = hand->bottom;
        hand->top = card;
        card->next->prev = card;
        card->prev->next = card;
    }

    hand->count++;
    return card_setlasterror(CARD_ERR_NONE);
}

/*
 * Returns the number of cards in the hand, or a (negative) error code.
 */
int card_hand_count(CARD_HAND * hand)
{
    if(hand == NULL)
        return -card_setlasterror(CARD_ERR_NULL);

    card_setlasterror(CARD_ERR_NONE);

    return hand->count;
}

/*
 * Removes the specified card from the hand.
 * Returns the card removed, or NULL if the card is not found.
 */
CARD_DATA * card_hand_remove(CARD_HAND * hand, int suit, int rank)
{
    CARD_DATA * card;

    if(hand == NULL)
    {
        card_setlasterror(CARD_ERR_NULL);
        return NULL;
    }

    if(hand->count == 0)
    {
        card_setlasterror(CARD_ERR_NOCARD);
        return NULL;
    }

    for(card=hand->top; ; card=card->next)
    {
        if(card->suit == suit && card->rank == rank)
        {
            if(--(hand->count) == 0)
            {
                hand->top = NULL;
                hand->bottom = NULL;
            }
            else
            {
                card->prev->next = card->next;
                card->next->prev = card->prev;
                if(hand->top == card)
                    hand->top = card->next;
                if(hand->bottom == card)
                    hand->bottom = card->prev;
            }
            break;
        }
        if(card == hand->bottom)
        {
            card_setlasterror(CARD_ERR_NOCARD);
            return NULL;
        }
    }

    card->prev = NULL;
    card->next = NULL;
    card_setlasterror(CARD_ERR_NONE);
    return card;
}

/*
 * Checks if the hand contains a visible card of the specified suit.
 * Returns -1 if true, 0 if false, or an error code on failure.
 */
int card_hand_hassuit(CARD_HAND * hand, int suit, int faceup)
{
    CARD_DATA * card;

    if(hand == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    card_setlasterror(CARD_ERR_NONE);

    if(hand->count == 0)
        return 0;

    for(card=hand->top; ; card=card->next)
    {
        if(card->suit == suit && card->faceup >= faceup)
            return -1;
        if(card == hand->bottom)
            return 0;
    }
}

/*
 * Checks if the hand contains a visible card of the specified rank.
 * Returns -1 if true, 0 if false, or an error code on failure.
 */
int card_hand_hasrank(CARD_HAND * hand, int rank, int faceup)
{
    CARD_DATA * card;

    if(hand == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    card_setlasterror(CARD_ERR_NONE);

    if(hand->count == 0)
        return 0;

    for(card=hand->top; ; card=card->next)
    {
        if(card->rank == rank && card->faceup >= faceup)
            return -1;
        if(card == hand->bottom)
            return 0;
    }
}

/*
 * Checks if the hand visibly contains the specified card.
 * Returns -1 if true, 0 if false, or an error code on failure.
 */
int card_hand_hascard(CARD_HAND * hand, int suit, int rank, int faceup)
{
    CARD_DATA * card;

    if(hand == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    card_setlasterror(CARD_ERR_NONE);

    if(hand->count == 0)
        return 0;

    for(card=hand->top; ; card=card->next)
    {
        if(card->suit == suit && card->rank == rank && card->faceup >= faceup)
            return -1;
        if(card == hand->bottom)
            return 0;
    }
}

/*
 * Returns a string representation of cards in the hand.
 * The returned string is allocated using str_dup() and should be
 *   released using free_string().
 */
char * card_hand_getallcards(CARD_HAND * hand, int faceup)
{
    CARD_DATA * card;
    char buf[CARD_LEN * 52 + 1];  /* data buffer */
    char fbuf[CARD_LEN * 52 + 1]; /* format buffer */

    if(hand == NULL)
    {
        card_setlasterror(CARD_ERR_NULL);
        return &str_empty[0];
    }

    if(hand->count == 0)
        return &str_empty[0];

    buf[0] = fbuf[0] = '\0';

    for(card=hand->top; ; card=card->next)
    {
        if(card->faceup >= faceup)
        {
            strcat(fbuf, "%s%s ");
            sprintf(buf, fbuf, suits[card->suit], ranks[card->rank]);
        }
        else
        {
            strcat(buf, "XX ");
        }
        strcpy(fbuf, buf);

        if(card == hand->bottom)
            break;
    }

    return str_dup(buf);
}

/*
 * Returns all cards in this hand to the deck.
 */
int card_hand_returntodeck(CARD_HAND * hand)
{
    CARD_HAND * returns;

    if(hand == NULL)
        return card_setlasterror(CARD_ERR_NULL);

    if(hand->count == 0) /* no cards to return, so done already */
        return card_setlasterror(CARD_ERR_NONE);

    returns = hand->deck->returns;

    if(returns->top == NULL)
    {
        returns->top = hand->top;
        returns->bottom = hand->bottom;
    }
    else
    {
        hand->bottom->next = returns->top;
        returns->top->prev = hand->bottom;
        hand->top->prev = returns->bottom;
        returns->bottom->next = hand->top;
        returns->bottom = hand->bottom;
    }

    returns->count += hand->count;
    hand->top = hand->bottom = NULL;
    hand->count = 0;

    return card_setlasterror(CARD_ERR_NONE);
}


/*
 * Other functions *************************************************************
 */

int card_setlasterror(int err)
{
    card_lasterror = err;
    return card_lasterror;
}

int card_getlasterror(void)
{
    return card_lasterror;
}

/*
 * Recycling stuff *************************************************************
 */

CARD_DATA * card_free;

CARD_DATA * new_card()
{
    CARD_DATA * card;

    if (card_free == NULL)
        card = alloc_perm(sizeof(*card));
    else
    { 
        card = card_free;
        card_free = card_free->next;
    }

    card->next = card->prev = NULL;
    return card;
}

void free_card(CARD_DATA * card)
{
    if (card == NULL)
        return;

    card->next = card_free;
    card_free  = card;
}

CARD_DECK * deck_free;

CARD_DECK * new_deck()
{
    CARD_DECK * deck;

    if (deck_free == NULL)
        deck = alloc_perm(sizeof(*deck));
    else
    { 
        deck = deck_free;
        deck_free = deck_free->next;
    }

    deck->next = NULL;
    return deck;
}

void free_deck(CARD_DECK * deck)
{
    if (deck == NULL)
        return;

    deck->next = deck_free;
    deck_free  = deck;
}

CARD_HAND * hand_free;

CARD_HAND * new_hand()
{
    CARD_HAND * hand;

    if (hand_free == NULL)
        hand = alloc_perm(sizeof(*hand));
    else
    { 
        hand = hand_free;
        hand_free = hand_free->next;
    }

    hand->next = NULL;
    return hand;
}

void free_hand(CARD_HAND * hand)
{
    if (hand == NULL)
        return;

    hand->next = hand_free;
    hand_free  = hand;
}

/******************************************************************************\
*   Card code is Copyright 2005 Cameron Taylor                                 *
*   Developed by Cameron Taylor (Shanyr) for the Mud Magic Code Challenge      *
*   See included 'card_license.txt' for license conditions.                    *
\******************************************************************************/

/*
 * Typedefs and structures *****************************************************
 */
typedef struct card_data CARD_DATA;
typedef struct card_deck CARD_DECK;
typedef struct card_hand CARD_HAND;


struct card_data
{
    CARD_DECK * deck; /* the deck to which this card belongs */
    CARD_DATA * prev;
    CARD_DATA * next;
    int         suit;
    int         rank;
    int         faceup;
};

struct card_deck
{
    CARD_DECK * next; /* used for recycling */
    CARD_DATA * top;
    CARD_DATA * bottom;
    CARD_HAND * hand_list; /* all hands dealt from this deck */
    CARD_HAND * returns;
    int         count;
};

struct card_hand
{
    CARD_DECK * deck; /* the deck from which this hand was dealt */
    CARD_HAND * next;
    CARD_DATA * top;
    CARD_DATA * bottom;
    int         count;
};


/*
 * Constants *******************************************************************
 */

#define CARD_SUIT_SPADES   0
#define CARD_SUIT_CLUBS    1
#define CARD_SUIT_DIAMONDS 2
#define CARD_SUIT_HEARTS   3
#define CARD_SUIT_MIN      0
#define CARD_SUIT_MAX      3

#define CARD_RANK_MIN      0 /* Ace */
#define CARD_RANK_MAX     12 /* King */

#define CARD_FACEDOWN      0 /* Card face cannot be seen by anyone */
#define CARD_FACEHOLDER    1 /* Card face can only be seen by holder */
#define CARD_FACEUP        2 /* Card face can be seen by everyone */


/*
 * Error codes *****************************************************************
 */

#define CARD_ERR_NONE   0 /* No error */
#define CARD_ERR_NULL   1 /* A NULL pointer was passed */
#define CARD_ERR_DECK   2 /* A card was used with the wrong deck */
#define CARD_ERR_NOCARD 3 /* A card was requested, but none was found */


/*
 * Prototypes ******************************************************************
 */

CARD_DECK * card_deck_create(void);
int card_deck_reset(CARD_DECK * deck);
int card_deck_destroy(CARD_DECK * deck);
int card_deck_shuffle(CARD_DECK * deck);
CARD_DATA * card_deck_drawtop(CARD_DECK * deck);
int card_deck_addbottom(CARD_DECK * deck, CARD_DATA * card);
int card_deck_count(CARD_DECK * deck);
char * card_deck_getallcards(CARD_DECK * deck);

CARD_HAND * card_hand_create(CARD_DECK * deck);
void card_hand_destroy(CARD_HAND * hand);
int card_hand_returntodeck(CARD_HAND * hand);
int card_hand_add(CARD_HAND * hand, CARD_DATA * card, int faceup);
CARD_DATA * card_hand_remove(CARD_HAND * hand, int suit, int rank);
int card_hand_count(CARD_HAND * hand);
int card_hand_hassuit(CARD_HAND * hand, int suit, int faceup);
int card_hand_hasrank(CARD_HAND * hand, int rank, int faceup);
int card_hand_hascard(CARD_HAND * hand, int suit, int rank, int faceup);
char * card_hand_getallcards(CARD_HAND * hand, int faceup);

int card_getlasterror(void);
